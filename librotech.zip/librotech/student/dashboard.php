<<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include('../config/database.php');

$cat = isset($_GET['categoria']) ? $_GET['categoria'] : '';
if ($cat != '') {
    $stmt = $pdo->prepare("SELECT * FROM libros WHERE categoria = ?");
    $stmt->execute([$cat]);
} else {
    $stmt = $pdo->query("SELECT * FROM libros");
}
$libros = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>LibroTech - Estudiante</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-dark bg-dark px-4">
        <span class="navbar-brand">📚 LibroTech - Alumno: <?php echo $_SESSION['nombre']; ?></span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <!-- Menú lateral con las categorías académicas -->
            <div class="col-md-3 mb-3">
                <h5>Categorías</h5>
                <ul class="list-group">
                    <a href="dashboard.php" class="list-group-item list-group-item-action"> Todos los libros</a>
                    <a href="dashboard.php?categoria=Ingeniería de Software" class="list-group-item list-group-item-action">Ingeniería de Software</a>
                    <a href="dashboard.php?categoria=Redes" class="list-group-item list-group-item-action">Redes</a>
                    <a href="dashboard.php?categoria=Base de Datos" class="list-group-item list-group-item-action"> Base de Datos</a>
                    <a href="dashboard.php?categoria=Programación" class="list-group-item list-group-item-action"> Programación</a>
                </ul>
            </div>

            <!-- Contenido del catálogo -->
            <div class="col-md-9">
                <h3><?php echo $cat ? "Categoría: " . $cat : "Catálogo de Libros"; ?></h3>
                <hr>
                <div class="row">
                    <?php if (count($libros) > 0): ?>
                        <?php foreach($libros as $libro): ?>
                            <div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <img src="../uploads/<?php echo $libro['portada']; ?>" class="card-img-top" height="170" style="object-fit: cover;" onerror="this.src='https://via.placeholder.com/150x200?text=Sin+Portada'">
                                    <div class="card-body d-flex flex-column">
                                        <h5 class="card-title fs-6"><?php echo $libro['titulo']; ?></h5>
                                        <p class="text-muted small mb-1">Autor: <?php echo $libro['autor']; ?></p>
                                        <p class="small mb-3">
                                            <span class="badge bg-secondary"><?php echo $libro['categoria']; ?></span>
                                            <span class="badge bg-info text-dark">Stock: <?php echo $libro['stock']; ?></span>
                                        </p>
                                        
                                        <div class="mt-auto">
                                            <?php if($libro['stock'] > 0): ?>
                                                <form action="../librarian/prestamos_crud.php" method="POST">
                                                    <input type="hidden" name="libro_id" value="<?php echo $libro['id']; ?>">
                                                    <button type="submit" class="btn btn-primary btn-sm w-100">Solicitar Préstamo</button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-secondary btn-sm w-100" disabled>Sin Stock</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="alert alert-warning text-center">No hay libros registrados en esta categoría.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</body>
</html>