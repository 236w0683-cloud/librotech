<?php
session_start();
require_once '../config/database.php';

// Verificar que haya sesión iniciada (sea estudiante o admin)
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$mensaje = "";
$tipo_alerta = "";

// 1. SI ES UNA SOLICITUD DE PRÉSTAMO DESDE EL PANEL DE ESTUDIANTE (POST con libro_id)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['libro_id']) && !isset($_POST['prestamo_id'])) {
    $libro_id = intval($_POST['libro_id']);
    $usuario_id = $_SESSION['user_id'];

    try {
        $pdo->beginTransaction();

        // Verificar stock disponible
        $stmtStock = $pdo->prepare("SELECT stock FROM libros WHERE id = ?");
        $stmtStock->execute([$libro_id]);
        $libro = $stmtStock->fetch();

        if ($libro && $libro['stock'] > 0) {
            // Registrar el préstamo con estado 'Pendiente'
            $stmtPrestamo = $pdo->prepare("INSERT INTO prestamos (usuario_id, libro_id, estado, fecha_prestamo) VALUES (?, ?, 'Pendiente', NOW())");
            $stmtPrestamo->execute([$usuario_id, $libro_id]);

            // Descontar 1 al stock
            $stmtUpdateStock = $pdo->prepare("UPDATE libros SET stock = stock - 1 WHERE id = ?");
            $stmtUpdateStock->execute([$libro_id]);

            $pdo->commit();
            
            // Redirigir de regreso al panel del estudiante con éxito
            header("Location: ../student/dashboard.php?exito=1");
            exit;
        } else {
            $pdo->rollBack();
            echo "<script>alert('Lo sentimos, este libro ya no tiene stock disponible.'); window.location.href='../student/dashboard.php';</script>";
            exit;
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "<script>alert('Ocurrió un error al procesar tu solicitud.'); window.location.href='../student/dashboard.php';</script>";
        exit;
    }
}

// 2. SI ES UNA DEVOLUCIÓN (ADMIN/BIBLIOTECARIO)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prestamo_id']) && isset($_POST['libro_id'])) {
    // Verificar que sea bibliotecario para devolver
    if (!isset($_SESSION['rol_id']) || $_SESSION['rol_id'] != 1) {
        header("Location: ../login.php");
        exit;
    }

    $prestamo_id = intval($_POST['prestamo_id']);
    $libro_id = intval($_POST['libro_id']);

    try {
        $pdo->beginTransaction();

        $stmtUpdatePrestamo = $pdo->prepare("UPDATE prestamos SET estado = 'Devuelto' WHERE id = ?");
        $stmtUpdatePrestamo->execute([$prestamo_id]);

        $stmtUpdateStock = $pdo->prepare("UPDATE libros SET stock = stock + 1 WHERE id = ?");
        $stmtUpdateStock->execute([$libro_id]);

        $pdo->commit();
        $mensaje = "¡Devolución registrada con éxito! Stock recuperado.";
        $tipo_alerta = "success";
    } catch (Exception $e) {
        $pdo->rollBack();
        $mensaje = "Error al procesar la devolución.";
        $tipo_alerta = "danger";
    }
}

// Obtener todos los préstamos para la vista del bibliotecario
$stmtPrestamos = $pdo->query("
    SELECT p.id as prestamo_id, u.nombre as estudiante, l.id as libro_id, l.titulo, l.categoria, p.estado, p.fecha_prestamo 
    FROM prestamos p 
    JOIN usuarios u ON p.usuario_id = u.id 
    JOIN libros l ON p.libro_id = l.id 
    ORDER BY p.id DESC
");
$prestamos = $stmtPrestamos->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Bibliotecario - LibroTech</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark px-4">
        <a class="navbar-brand" href="#">LibroTech - Panel Bibliotecario</a>
        <div class="ms-auto">
            <span class="text-white me-3">Hola, <?php echo htmlspecialchars($_SESSION['nombre'] ?? 'Administrador', ENT_QUOTES, 'UTF-8'); ?></span>
            <a href="../logout.php" class="btn btn-danger btn-sm">Cerrar Sesión</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if($mensaje): ?>
            <div class="alert alert-<?php echo $tipo_alerta; ?>"><?php echo htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <h3>Gestión de Préstamos y Devoluciones</h3>
        <p class="text-muted">Control general de solicitudes de los estudiantes y recepción de material bibliográfico.</p>
        <hr>

        <table class="table table-striped bg-white shadow-sm rounded">
            <thead>
                <tr>
                    <th>Estudiante</th>
                    <th>Libro Solicitado</th>
                    <th>Categoría</th>
                    <th>Estado</th>
                    <th>Fecha de Préstamo</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($prestamos) > 0): ?>
                    <?php foreach($prestamos as $p): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p['estudiante'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($p['titulo'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>
                                <span class="badge bg-secondary">
                                    <?php echo htmlspecialchars($p['categoria'], ENT_QUOTES, 'UTF-8'); ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo ($p['estado'] == 'Pendiente') ? 'warning' : 'success'; ?>">
                                    <?php echo $p['estado']; ?>
                                </span>
                            </td>
                            <td><?php echo $p['fecha_prestamo']; ?></td>
                            <td>
                                <?php if($p['estado'] == 'Pendiente'): ?>
                                    <form action="prestamos_crud.php" method="POST">
                                        <input type="hidden" name="prestamo_id" value="<?php echo $p['prestamo_id']; ?>">
                                        <input type="hidden" name="libro_id" value="<?php echo $p['libro_id']; ?>">
                                        <button type="submit" class="btn btn-primary btn-sm">Registrar Devolución (+1 Stock)</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">Completado</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center">No hay préstamos registrados en el sistema.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>