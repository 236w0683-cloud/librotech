<?php
session_start();
// Verificar que sea el bibliotecario (rol_id = 1)
if (!isset($_SESSION['user_id']) || $_SESSION['rol_id'] != 1) {
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
$mensaje = "";
$tipo_alerta = "";

// Procesar Devolución de Libro (Lógica transaccional requerida por la rúbrica)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prestamo_id']) && isset($_POST['libro_id'])) {
    $prestamo_id = intval($_POST['prestamo_id']);
    $libro_id = intval($_POST['libro_id']);

    try {
        $pdo->beginTransaction();

        // 1. Cambiar el estado del préstamo a 'Devuelto'
        $stmtUpdatePrestamo = $pdo->prepare("UPDATE prestamos SET estado = 'Devuelto' WHERE id = ?");
        $stmtUpdatePrestamo->execute([$prestamo_id]);

        // 2. Recuperar y sumar 1 al stock del libro
        $stmtUpdateStock = $pdo->prepare("UPDATE libros SET stock = stock + 1 WHERE id = ?");
        $stmtUpdateStock->execute([$libro_id]);

        $pdo->commit();
        $mensaje = "¡Devolución registrada con éxito! Stock recuperado en +1.";
        $tipo_alerta = "success";
    } catch (Exception $e) {
        $pdo->rollBack();
        $mensaje = "Error al procesar la devolución.";
        $tipo_alerta = "danger";
    }
}

// Obtener todos los préstamos solicitados por los estudiantes
$stmtPrestamos = $pdo->query("
    SELECT p.id as prestamo_id, u.nombre as estudiante, l.id as libro_id, l.titulo, p.estado, p.fecha_prestamo 
    FROM prestamos p 
    JOIN usuarios u ON p.usuario_id = u.id 
    JOIN libros l ON p.libro_id = l.id 
    ORDER BY p.id DESC
");
$prestamos = $stmtPrestamos->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Bibliotecario - LibroTech</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark px-4">
        <a class="navbar-brand" href="#">LibroTech - Panel Bibliotecario</a>
        <div class="ms-auto">
            <span class="text-white me-3">Hola, <?php echo htmlspecialchars($_SESSION['nombre'], ENT_QUOTES, 'UTF-8'); ?></span>
            <a href="../logout.php" class="btn btn-danger btn-sm">Cerrar Sesión</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if($mensaje): ?>
            <div class="alert alert-<?php echo $tipo_alerta; ?>"><?php echo htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Gestión de Préstamos y Devoluciones</h3>
            <!-- Enlace corregido para abrir el archivo que sí existe en la carpeta -->
            <a href="prestamos_crud.php" class="btn btn-primary">Ver Módulo de Préstamos</a>
        </div>
        <p class="text-muted">Control general de solicitudes de los estudiantes y recepción de material bibliográfico.</p>
        <hr>

        <table class="table table-striped bg-white shadow-sm rounded">
            <thead>
                <tr>
                    <th>Estudiante</th>
                    <th>Libro Solicitado</th>
                    <th>Estado</th>
                    <th>Fecha de Préstamo</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($prestamos) > 0): ?>
                    <?php foreach($prestamos as $p): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p['estudiante'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($p['titulo'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo ($p['estado'] == 'Pendiente') ? 'warning' : 'success'; ?>">
                                    <?php echo $p['estado']; ?>
                                </span>
                            </td>
                            <td><?php echo $p['fecha_prestamo']; ?></td>
                            <td>
                                <?php if($p['estado'] == 'Pendiente'): ?>
                                    <form action="dashboard.php" method="POST">
                                        <input type="hidden" name="prestamo_id" value="<?php echo $p['prestamo_id']; ?>">
                                        <input type="hidden" name="libro_id" value="<?php echo $p['libro_id']; ?>">
                                        <button type="submit" class="btn btn-success btn-sm">Registrar Devolución (+1 Stock)</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">Completado</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">No hay préstamos registrados en el sistema.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>