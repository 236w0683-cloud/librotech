# Documentación del Proyecto: LibroTech

## 1. Guía de Instalación Rápida (XAMPP / Laragon)
1. Coloca la carpeta completa del proyecto dentro del directorio raíz de tu servidor local (`C:/xampp/htdocs/librotech/`).
2. Inicia los servicios de **Apache** y **MySQL** desde el panel de control de XAMPP o Laragon.
3. Abre phpMyAdmin en tu navegador web ingresando a `http://localhost/phpmyadmin/`.
4. Crea una nueva base de datos llamada **`librotech_db`**.
5. Selecciona la base de datos, ve a la pestaña **Importar**, sube el archivo **`schema.sql`** incluido en el proyecto y ejecútalo para cargar las tablas y datos iniciales.
6. Abre tu navegador y entra a la ruta del sistema: `http://localhost/librotech/`

---

## 2. Credenciales de Prueba (Datos Semilla)
Utiliza los siguientes usuarios registrados en la base de datos para probar los distintos niveles de acceso:

* **Rol Bibliotecario (Administrador):**
  * **Correo:** `bibliotecario@librotech.com`
  * **Contraseña:** `123456`

* **Rol Estudiante:**
  * **Correo:** `estudiante@librotech.com`
  * **Contraseña:** `123456`

---

## 3. Diagrama Entidad-Relación (E-R)
Estructura relacional de la base de datos:

```text
[ usuarios ] (1) ------< (N) [ prestamos ] >------ (1) [ libros ]# Documentación del Proyecto: LibroTech

## 1. Guía de Instalación Rápida (XAMPP / Laragon)
1. Coloca la carpeta completa del proyecto dentro del directorio raíz de tu servidor local (`C:/xampp/htdocs/librotech/`).
2. Inicia los servicios de **Apache** y **MySQL** desde el panel de control de XAMPP o Laragon.
3. Abre phpMyAdmin en tu navegador web ingresando a `http://localhost/phpmyadmin/`.
4. Crea una nueva base de datos llamada **`librotech_db`**.
5. Selecciona la base de datos, ve a la pestaña **Importar**, sube el archivo **`schema.sql`** incluido en el proyecto y ejecútalo para cargar las tablas y datos iniciales.
6. Abre tu navegador y entra a la ruta del sistema: `http://localhost/librotech/`

---

## 2. Credenciales de Prueba (Datos Semilla)
Utiliza los siguientes usuarios registrados en la base de datos para probar los distintos niveles de acceso:

* **Rol Bibliotecario (Administrador):**
  * **Correo:** `bibliotecario@librotech.com`
  * **Contraseña:** `123456`

* **Rol Estudiante:**
  * **Correo:** `estudiante@librotech.com`
  * **Contraseña:** `123456`

---

## 3. Diagrama Entidad-Relación (E-R)
Estructura relacional de la base de datos:

```text
[ usuarios ] (1) ------< (N) [ prestamos ] >------ (1) [ libros ]# Documentación del Proyecto: LibroTech

## 1. Guía de Instalación Rápida (XAMPP / Laragon)
1. Coloca la carpeta completa del proyecto dentro del directorio raíz de tu servidor local (`C:/xampp/htdocs/librotech/`).
2. Inicia los servicios de **Apache** y **MySQL** desde el panel de control de XAMPP o Laragon.
3. Abre phpMyAdmin en tu navegador web ingresando a `http://localhost/phpmyadmin/`.
4. Crea una nueva base de datos llamada **`librotech_db`**.
5. Selecciona la base de datos, ve a la pestaña **Importar**, sube el archivo **`schema.sql`** incluido en el proyecto y ejecútalo para cargar las tablas y datos iniciales.
6. Abre tu navegador y entra a la ruta del sistema: `http://localhost/librotech/`

---

## 2. Credenciales de Prueba (Datos Semilla)
Utiliza los siguientes usuarios registrados en la base de datos para probar los distintos niveles de acceso:

* **Rol Bibliotecario (Administrador):**
  * **Correo:** `bibliotecario@librotech.com`
  * **Contraseña:** `123456`

* **Rol Estudiante:**
  * **Correo:** `estudiante@librotech.com`
  * **Contraseña:** `123456`

---

## 3. Diagrama Entidad-Relación (E-R)
Estructura relacional de la base de datos:

```text
[ usuarios ] (1) ------< (N) [ prestamos ] >------ (1) [ libros ]