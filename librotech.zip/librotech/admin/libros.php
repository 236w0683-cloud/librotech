<div class="mb-3">
    <label class="form-label font-weight-bold">Categoría o Género</label>
    <select name="categoria" class="form-control" required>
        <option value="Romance">Romance</option>
        <option value="Terror">Terror</option>
        <option value="Suspenso">Suspenso</option>
        <option value="Ciencia Ficción">Ciencia Ficción</option>
        <option value="General">General</option>
    </select>
</div>